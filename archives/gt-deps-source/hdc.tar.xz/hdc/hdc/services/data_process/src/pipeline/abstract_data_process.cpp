/*
 * Copyright (c) 2021 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "abstract_data_process.h"

#include "distributed_hardware_log.h"

namespace OHOS {
namespace DistributedHardware {
int32_t AbstractDataProcess::SetNextNode(std::shared_ptr<AbstractDataProcess>& nextDataProcess)
{
    if (nextDataProcess == nullptr) {
        DHLOGE("Next data process is invalid.");
        return DCAMERA_BAD_VALUE;
    }
    nextDataProcess_ = nextDataProcess;
    return DCAMERA_OK;
}

void AbstractDataProcess::SetNodeRank(size_t curNodeRank)
{
    nodeRank_ = curNodeRank;
}
} // namespace DistributedHardware
} // namespace OHOS
