// $Id$
// Copyright (c) 1996-2006 The Regents of the University of California. All
// Rights Reserved. Permission to use, copy, modify, and distribute this
// software and its documentation without fee, and without a written
// agreement is hereby granted, provided that the above copyright notice
// and this paragraph appear in all copies.  This software program and
// documentation are copyrighted by The Regents of the University of
// California. The software program and documentation are supplied "AS
// IS", without any accompanying services from The Regents. The Regents
// does not warrant that the operation of the program will be
// uninterrupted or error-free. The end-user understands that the program
// was developed for research purposes and is advised not to rely
// exclusively on the program for any reason.  IN NO EVENT SHALL THE
// UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
// SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
// ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
// THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
// WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
// PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
// CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT,
// UPDATES, ENHANCEMENTS, OR MODIFICATIONS.

package org.argouml.application.events;
import org.argouml.application.api.ArgoEventListener;

/** An interface that objects interested in NotationEvent
 *  notifications must extend.
 *
 *  @author Thierry Lach
 *  @since 0.9.4
 */

public interface ArgoNotationEventListener extends ArgoEventListener {

    /**
     * Invoked when any aspect of the notation has been changed.
     * @param e <code>ArgoNotationEvent</code> describing the change.
     */
    public void notationChanged(ArgoNotationEvent e);

    /**
     * Invoked when a notation has been added.
     * @param e <code>ArgoNotationEvent</code> describing the added notation.
     */
    public void notationAdded(ArgoNotationEvent e);

    /**
     * Invoked when a notation has been removed.
     * @param e <code>ArgoNotationEvent</code> describing the removed notation.
     */
    public void notationRemoved(ArgoNotationEvent e);

    /**
     * Invoked when a notation provider has been added.
     * @param e <code>ArgoNotationEvent</code> describing
     * the added notation provider.
     */
    public void notationProviderAdded(ArgoNotationEvent e);

    /**
     * Invoked when a notation provider has been removed.
     * @param e <code>ArgoNotationEvent</code> describing
     * the removed notation provider.
     */
    public void notationProviderRemoved(ArgoNotationEvent e);

}

